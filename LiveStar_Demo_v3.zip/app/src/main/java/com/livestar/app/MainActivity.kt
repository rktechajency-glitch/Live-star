package com.livestar.app

import android.app.Activity
import android.os.Bundle
import android.widget.Toast
import com.livestar.app.databinding.ActivityMainBinding

class MainActivity : Activity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val b = ActivityMainBinding.inflate(layoutInflater)
  setContentView(b.root)
  b.liveRoom.setOnClickListener { toast("Demo Live Room: video area + viewers + gifts") }
  b.chat.setOnClickListener { toast("Live Chat: demo messages") }
  b.gifts.setOnClickListener { toast("Gifts: ❤️ 🌹 💎 🎁 (demo only)") }
  b.coins.setOnClickListener { toast("Coins: demo balance 10,000") }
  b.wallet.setOnClickListener { toast("Wallet: demo withdrawal screen") }
  b.host.setOnClickListener { toast("Host: hours, gifts, earnings and level") }
  b.agency.setOnClickListener { toast("Agency: hosts, commission and reports") }
  b.profile.setOnClickListener { toast("Profile and settings") }
 }
 private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
